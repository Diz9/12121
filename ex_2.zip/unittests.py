import unittest
from unittest.mock import patch, MagicMock

from visualizer import get_package_dependencies, fetch_dependencies, build_dependency_graph


class TestDependencyVisualizer(unittest.TestCase):

    @patch('requests.get')
    def test_get_package_dependencies(self, mock_get):
        html_content = '''
        <html>
            <body>
                <details open="">
                    <summary>Depends (11)</summary>
                    <div class="pure-menu custom-restricted-width">
                        <ul class="pure-menu-list">
                            <li class="pure-menu-item">
                                <a class="pure-menu-link" href="/package/edge/main/x86_64/ca-certificates-bundle">
                                    ca-certificates-bundle
                                </a>
                            </li>
                            <li class="pure-menu-item">
                                <a class="pure-menu-link" href="/package/edge/main/x86_64/brotli-libs">
                                    so:libbrotlidec.so.1
                                </a>
                            </li>
                        </ul>
                    </div>
                </details>
            </body>
        </html>
        '''
        mock_get.return_value = MagicMock(status_code=200, text=html_content)

        url = "https://pkgs.alpinelinux.org/package/edge/main/x86_64/libcurl"
        dependencies = get_package_dependencies(url)
        self.assertEqual(dependencies, ['ca-certificates-bundle', 'so:libbrotlidec.so.1'])

    @patch('requests.get')
    def test_fetch_dependencies(self, mock_get):
        html_content = '''
        <html>
            <body>
                <details open="">
                    <summary>Depends (11)</summary>
                    <div class="pure-menu custom-restricted-width">
                        <ul class="pure-menu-list">
                            <li class="pure-menu-item">
                                <a class="pure-menu-link" href="/package/edge/main/x86_64/ca-certificates-bundle">
                                    ca-certificates-bundle
                                </a>
                            </li>
                            <li class="pure-menu-item">
                                <a class="pure-menu-link" href="/package/edge/main/x86_64/brotli-libs">
                                    so:libbrotlidec.so.1
                                </a>
                            </li>
                        </ul>
                    </div>
                </details>
            </body>
        </html>
        '''
        mock_get.return_value = MagicMock(status_code=200, text=html_content)

        repo_url = "https://pkgs.alpinelinux.org"
        dependencies = fetch_dependencies('libcurl', repo_url, max_depth=1)

        self.assertIn('libcurl', dependencies)
        self.assertIn('ca-certificates-bundle', dependencies['libcurl'])
        self.assertIn('so:libbrotlidec.so.1', dependencies['libcurl'])

    @patch('requests.get')
    def test_fetch_dependencies_max_depth(self, mock_get):
        html_content = '''
        <html>
            <body>
                <details open="">
                    <summary>Depends (11)</summary>
                    <div class="pure-menu custom-restricted-width">
                        <ul class="pure-menu-list">
                            <li class="pure-menu-item">
                                <a class="pure-menu-link" href="/package/edge/main/x86_64/ca-certificates-bundle">
                                    ca-certificates-bundle
                                </a>
                            </li>
                        </ul>
                    </div>
                </details>
            </body>
        </html>
        '''
        mock_get.return_value = MagicMock(status_code=200, text=html_content)

        repo_url = "https://pkgs.alpinelinux.org"
        dependencies = fetch_dependencies('libcurl', repo_url, max_depth=1)

        self.assertEqual(dependencies['libcurl'], {'ca-certificates-bundle'})


if __name__ == '__main__':
    unittest.main()
