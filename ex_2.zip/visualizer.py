import json
import requests
from bs4 import BeautifulSoup
from graphviz import Digraph
import os

os.environ["PATH"] += os.pathsep + r"C:\Program Files (x86)\Graphviz\bin"


def get_package_dependencies(url):
    response = requests.get(url)
    if response.status_code != 200:
        print(f"Ошибка при загрузке страницы: {response.status_code}")
        return []

    soup = BeautifulSoup(response.text, 'html.parser')

    details = soup.find('details', {'open': ''})
    if not details:
        print("Зависимости не найдены.")
        return []

    dependencies = []
    ul = details.find('ul', class_='pure-menu-list')
    if ul:
        for li in ul.find_all('li', class_='pure-menu-item'):
            dep_name = li.find('a', class_='pure-menu-link').get_text(strip=True)
            dependencies.append(dep_name)

    return dependencies


def fetch_dependencies(package_name, repo_url, visited=None, current_depth=0, max_depth=2):
    if visited is None:
        visited = set()

    if package_name in visited:
        return {}

    visited.add(package_name)

    if current_depth >= max_depth:
        return {package_name: set()}

    url = f"{repo_url}/package/edge/main/x86_64/{package_name}"
    dependencies = get_package_dependencies(url)
    if not dependencies:
        print(f"Зависимости для пакета {package_name} не найдены.")
        return {}

    print(f"Найденные зависимости для {package_name}: {dependencies}")  # Отладочный вывод
    result = {package_name: set(dependencies)}

    for dep in dependencies:
        result.update(fetch_dependencies(dep, repo_url, visited, current_depth + 1, max_depth))

    return result


def build_dependency_graph(dependencies, output_path):
    if not dependencies:
        print("Нет зависимостей для построения графа.")
        return

    graph = Digraph(format='png')

    for package, deps in dependencies.items():
        if package != "so":
            for dep in deps:
                dep_label = dep.replace("so:", "") if dep.startswith("so:") else dep
                dep_label = dep_label.replace(".so.", "")

                print(f"Добавляем зависимость: {package} -> {dep_label}")

                graph.edge(package, dep_label)

    if len(graph.body) == 0:
        print("Граф пустой!")
        return

    graph.render(output_path, cleanup=True)
    print(f"Граф зависимостей сохранён в {output_path}.png")


def main(config_path):
    with open(config_path, 'r') as config_file:
        config = json.load(config_file)

    package_name = config['package_name']
    repo_url = config['repo_url']
    output_path = config['output_path']

    print(f"Поиск зависимостей для пакета {package_name}...")
    dependencies = fetch_dependencies(package_name, repo_url, max_depth=2)
    if not dependencies:
        print("Зависимости не найдены.")
        return

    print("Генерация графа зависимостей...")
    build_dependency_graph(dependencies, output_path)

    print("Операция завершена успешно.")


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description="Визуализатор графа зависимостей пакетов Alpine Linux.")
    parser.add_argument('config', help="Путь к конфигурационному файлу JSON.")
    args = parser.parse_args()

    main(args.config)
