import os
import zipfile
import sys
import xml.etree.ElementTree as ET


class VShell:
    def __init__(self, config_file):
        self.load_config(config_file)
        self.zip = zipfile.ZipFile(self.vfs_path, 'r')
        self.current_path = ""
        self.run_startup_script()

    def load_config(self, config_file):
        tree = ET.parse(config_file)
        root = tree.getroot()
        self.user_name = root.find('username').text
        self.vfs_path = root.find('vfs_path').text
        self.startup_script = root.find('startup_script').text

    def run_startup_script(self):
        if self.startup_script and os.path.exists(self.startup_script):
            with open(self.startup_script, 'r') as script:
                for line in script:
                    self.execute_command(line.strip())

    def run(self):
        print("Welcome to vshell! Type 'exit' to quit.")
        while True:
            user_input = input(f"{self.user_name}:{self.current_path} $ ").strip()
            if user_input.lower() == 'exit':
                break
            self.execute_command(user_input)

    def execute_command(self, command):
        if command.lower() == 'exit':
            sys.exit()
        if command.startswith('cd'):
            self.change_directory(command[2:].strip())
        elif command.startswith('ls'):
            self.list_directory()
        elif command.startswith('pwd'):
            self.print_working_directory()
        elif command.startswith('head'):
            self.show_file_head(command[4:].strip())
        elif command.startswith('tac'):
            self.show_file_tac(command[3:].strip())
        else:
            print("Invalid command. Supported commands: ls, cd, pwd, head, tac, exit")

    def change_directory(self, path):
        new_path = os.path.normpath(os.path.join(self.current_path, path))
        if new_path == ".":
            self.current_path = ""
        elif any(file.startswith(new_path) for file in self.zip.namelist()):
            self.current_path = new_path
        else:
            print(f"cd: no such directory: {path}")

    def list_directory(self):
        items = set()
        for file in self.zip.namelist():
            if self.current_path == "":
                items.add(file.split('/')[0])
            elif file.startswith(self.current_path):
                relative_path = file[len(self.current_path):].lstrip('/')
                items.add(relative_path.split('/')[0])
        for item in sorted(items):
            print(item)

    def print_working_directory(self):
        print(f"/{self.current_path}" if self.current_path else "/")

    def show_file_head(self, file, lines=10):
        file_path = self.resolve_path(file)
        if file_path and file_path in self.zip.namelist():
            with self.zip.open(file_path) as f:
                for i, line in enumerate(f):
                    if i >= lines:
                        break
                    print(line.decode().strip())
        else:
            print(f"head: cannot open '{file}' for reading: No such file")

    def show_file_tac(self, file):
        found = False
        if file.startswith("/") and file[1:] in self.zip.namelist():
            file = file[1:]
            found = True
        elif self.current_path + "/" + file in self.zip.namelist():
            file = self.current_path + "/" + file
            found = True
        elif file in self.zip.namelist():
            found = True

        if found:
            with self.zip.open(file) as f:
                lines = f.readlines()
            for line in reversed(lines):
                print(line.decode().strip())
        else:
            print(f"tac: cannot open '{file}' for reading: No such file")

    def resolve_path(self, file):
        if file.startswith('/'):
            return file.lstrip('/')
        return os.path.normpath(os.path.join(self.current_path, file)).lstrip('/')

    def close(self):
        self.zip.close()


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python vshell.py <config_file>")
        sys.exit(1)

    config_file = sys.argv[1]

    if not os.path.exists(config_file):
        print(f"Error: Configuration file '{config_file}' does not exist.")
        sys.exit(1)

    vshell = VShell(config_file)
    vshell.run()
