import unittest
import os
import zipfile
from io import StringIO
from contextlib import redirect_stdout
from vshell import VShell  # предположим, что код сохранен как vshell.py


class TestVShell(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Создаем временный zip-архив для тестов
        cls.zip_file = 'test_vfs.zip'
        with zipfile.ZipFile(cls.zip_file, 'w') as zipf:
            zipf.writestr('file1.txt', 'line1\nline2\nline3\nline4\nline5\nline6\nline7\nline8\nline9\nline10\nline11\n')
            zipf.writestr('dir1/file2.txt', 'content of file2')
            zipf.writestr('dir2/file3.txt', 'content of file3')

        # Создаем временный конфигурационный файл
        cls.config_file = 'test_config.xml'
        with open(cls.config_file, 'w') as f:
            f.write("""<config>
                        <username>testuser</username>
                        <vfs_path>test_vfs.zip</vfs_path>
                        <startup_script></startup_script>
                       </config>""")

    @classmethod
    def tearDownClass(cls):
        os.remove(cls.zip_file)
        os.remove(cls.config_file)

    def setUp(self):
        self.shell = VShell(self.config_file)

    def capture_output(self, func, *args, **kwargs):
        with StringIO() as buf, redirect_stdout(buf):
            func(*args, **kwargs)
            return buf.getvalue().strip()

    # Тесты для команды cd
    def test_cd_to_existing_directory(self):
        self.shell.change_directory('dir1')
        self.assertEqual(self.shell.current_path, 'dir1')

    def test_cd_to_root(self):
        self.shell.change_directory('dir1')
        self.shell.change_directory('..')
        self.assertEqual(self.shell.current_path, '')

    def test_cd_to_non_existing_directory(self):
        output = self.capture_output(self.shell.change_directory, 'nonexistent')
        self.assertIn('cd: no such directory', output)

    # Тесты для команды ls
    def test_ls_root(self):
        output = self.capture_output(self.shell.list_directory)
        self.assertIn('file1.txt', output)
        self.assertIn('dir1', output)
        self.assertIn('dir2', output)

    def test_ls_subdirectory(self):
        self.shell.change_directory('dir1')
        output = self.capture_output(self.shell.list_directory)
        self.assertIn('file2.txt', output)

    def test_ls_empty_directory(self):
        self.shell.change_directory('dir2')
        output = self.capture_output(self.shell.list_directory)
        self.assertIn('file3.txt', output)

    # Тесты для команды tac
    def test_tac_file_in_root(self):
        output = self.capture_output(self.shell.show_file_tac, 'file1.txt')
        self.assertTrue(output.startswith('line11'))

    def test_tac_file_in_subdirectory(self):
        self.shell.change_directory('dir1')
        output = self.capture_output(self.shell.show_file_tac, 'file2.txt')
        self.assertEqual(output, 'content of file2')

    def test_tac_non_existing_file(self):
        output = self.capture_output(self.shell.show_file_tac, 'nonexistent.txt')
        self.assertIn('tac: cannot open', output)

    # Тесты для команды head
    def test_head_file_in_root(self):
        output = self.capture_output(self.shell.show_file_head, 'file1.txt')
        self.assertTrue(output.startswith('line1'))

    def test_head_non_existing_file(self):
        output = self.capture_output(self.shell.show_file_head, 'nonexistent.txt')
        self.assertIn('head: cannot open', output)

    # Тесты для команды exit
    def test_exit(self):
        with self.assertRaises(SystemExit):
            self.shell.execute_command('exit')


if __name__ == '__main__':
    unittest.main()
