import unittest
from main import yaml_to_custom_language, format_value

class TestYamlToCustomLanguage(unittest.TestCase):

    def test_simple_dict(self):
        data = {"key": "value"}
        result = yaml_to_custom_language(data)
        expected = "{\n  key = value;\n}"
        self.assertEqual(result, expected)

    def test_nested_dict(self):
        data = {"outer": {"inner": 42}}
        result = yaml_to_custom_language(data)
        expected = "{\n  outer = {\n    inner = 42;\n  };\n}"
        self.assertEqual(result, expected)

    def test_simple_list(self):
        data = ["item1", "item2", 123]
        result = yaml_to_custom_language(data)
        expected = "<< item1, item2, 123 >>"
        self.assertEqual(result, expected)

    def test_nested_list(self):
        data = [["item1", "item2"], [1, 2, 3]]
        result = yaml_to_custom_language(data)
        expected = "<< << item1, item2 >>, << 1, 2, 3 >> >>"
        self.assertEqual(result, expected)


    def test_empty_list(self):
        data = []
        result = yaml_to_custom_language(data)
        expected = "<< >>"
        self.assertEqual(result, expected)

    def test_invalid_type(self):
        data = {"key": set([1, 2, 3])}
        with self.assertRaises(ValueError):
            yaml_to_custom_language(data)


if __name__ == "__main__":
    unittest.main()
