import yaml
import argparse
import sys


def parse_yaml(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            return yaml.safe_load(file)
    except Exception as e:
        print(f"Ошибка при чтении файла YAML: {e}", file=sys.stderr)
        sys.exit(1)


def format_value(value, indent=0):
    indent_space = " " * (indent * 2)  # Два пробела на уровень вложенности
    if isinstance(value, dict):
        if not value:  # Пустой словарь
            return "{}"  # Убираем лишние символы новой строки
        formatted = "{\n"
        for k, v in value.items():
            formatted += f"{indent_space}  {k} = {format_value(v, indent + 1)};\n"
        formatted += f"{indent_space}}}"
        return formatted
    elif isinstance(value, list):
        if not value:  # Пустой список
            return "<< >>"  # Убираем лишние символы новой строки
        formatted = "<< "
        formatted += ", ".join(format_value(v, indent + 1).strip() for v in value)
        formatted += " >>"
        return formatted
    elif isinstance(value, (int, float)):
        return str(value)
    elif isinstance(value, str):
        return value
    else:
        raise ValueError(f"Неподдерживаемый тип значения: {type(value)}")

def yaml_to_custom_language(data):
    if isinstance(data, dict):
        # Форматируем словарь с правильными отступами
        return "{\n" + "\n".join(f"  {k} = {format_value(v, 1)};" for k, v in data.items()) + "\n}"
    elif isinstance(data, list):
        # Форматируем список с правильными отступами
        if not data:  # Пустой список
            return "<< >>"
        formatted = "<< "
        formatted += ", ".join(format_value(v, 1).strip() for v in data)
        formatted += " >>"
        return formatted
    else:
        raise ValueError("Корневая структура должна быть словарём или массивом")





if __name__ == "__main__":
    main()
